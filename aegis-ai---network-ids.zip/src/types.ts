/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AttackCategory = 'NORMAL' | 'DoS' | 'Probe' | 'R2L' | 'U2R';

export interface Packet {
  id: string;
  timestamp: string;
  src_ip: string;
  dst_ip: string;
  dst_port: number;
  protocol: string;
  category: AttackCategory;
  confidence: number;
  is_anomaly: boolean;
  iso_score: number;
  binary: 0 | 1;
  explanation?: AttackExplanation;
  features: number[];
}

export interface AttackExplanation {
  attack_name: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'NORMAL';
  narrative: string;
  mitigation: string;
  indicators: Indicator[];
  top_features: FeatureImportance[];
  icon: string;
}

export interface Indicator {
  feature: string;
  value: number | string;
  threshold: string;
  description: string;
}

export interface FeatureImportance {
  feature: string;
  importance: number;
}

export interface IDSMetadata {
  feature_names: string[];
  class_names_multi: AttackCategory[];
  n_train: number;
  n_test: number;
}

export interface SimulationStats {
  totalPackets: number;
  attackCounts: Record<AttackCategory, number>;
  anomalyCount: number;
}
