/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Shield, Activity, BarChart3, Brain, Search, List, Play, Square, Clock } from 'lucide-react';
import { Packet, AttackCategory } from './types';
import { LiveMonitor } from './components/LiveMonitor';
import { Analytics } from './components/Analytics';
import { ModelPerformance } from './components/ModelPerformance';
import { ExplainAlert } from './components/ExplainAlert';
import { LogsPanel } from './components/LogsPanel';

type TabType = 'monitor' | 'analytics' | 'model' | 'explain' | 'logs';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('monitor');
  const [isRunning, setIsRunning] = useState(false);
  const [history, setHistory] = useState<Packet[]>([]);
  const [anomalyScores, setAnomalyScores] = useState<number[]>([]);
  const [totalPackets, setTotalPackets] = useState(0);
  const [attackCounts, setAttackCounts] = useState<Record<AttackCategory, number>>({
    'NORMAL': 0, 'DoS': 0, 'Probe': 0, 'R2L': 0, 'U2R': 0
  });
  const [simulationMode, setSimulationMode] = useState<AttackCategory | 'RANDOM'>('RANDOM');
  const [packetsPerSecond, setPacketsPerSecond] = useState(2);
  const [currentTime, setCurrentTime] = useState(new Date());

  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(async () => {
        try {
          const res = await fetch('/api/simulate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              count: packetsPerSecond, 
              force_type: simulationMode === 'RANDOM' ? undefined : simulationMode 
            })
          });
          const data = await res.json();
          const newPackets: Packet[] = data.packets;

          setHistory(prev => [...newPackets.reverse(), ...prev].slice(0, 500));
          setTotalPackets(prev => prev + newPackets.length);
          
          setAttackCounts(prev => {
            const next = { ...prev };
            newPackets.forEach(p => {
              next[p.category] = (next[p.category] || 0) + 1;
            });
            return next;
          });

          setAnomalyScores(prev => [
            ...prev, 
            ...newPackets.map(p => p.iso_score)
          ].slice(-60));

        } catch (error) {
          console.error('Simulation error:', error);
        }
      }, 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, packetsPerSecond, simulationMode]);

  const tabs = [
    { id: 'monitor', label: 'Live Monitor', icon: Activity },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'model', label: 'Model Performance', icon: Brain },
    { id: 'explain', label: 'Explain Alert', icon: Search },
    { id: 'logs', label: 'System Logs', icon: List },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-bg-card border-b border-border-dim px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="bg-neon-blue/10 p-2 rounded-lg border border-neon-blue/30">
            <Shield className="w-6 h-6 text-neon-blue" />
          </div>
          <div>
            <h1 className="text-xl font-black neon-gradient-text tracking-tighter uppercase">Aegis AI - Network IDS</h1>
            <p className="text-[10px] text-text-dim font-bold uppercase tracking-widest">Autonomous Threat Detection Engine v4.2</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden md:flex flex-col items-end">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-neon-green animate-pulse' : 'bg-neon-red'}`} />
              <span className="text-xs font-bold uppercase tracking-widest">
                System {isRunning ? 'Active' : 'Standby'}
              </span>
            </div>
            <div className="flex items-center gap-1 text-[10px] text-text-muted font-mono">
              <Clock className="w-3 h-3" />
              {currentTime.toLocaleTimeString()}
            </div>
          </div>
        </div>
      </header>

      {/* Controls Bar */}
      <div className="bg-bg-elevated border-b border-border-dim px-6 py-3 flex flex-wrap items-center gap-6">
        <div className="flex items-center gap-3">
          <span className="text-[10px] font-bold text-text-dim uppercase">Traffic Mode</span>
          <select 
            value={simulationMode}
            onChange={(e) => setSimulationMode(e.target.value as any)}
            className="bg-bg-primary border border-border-dim rounded-md px-3 py-1.5 text-xs font-bold focus:outline-none focus:border-neon-blue"
          >
            <option value="RANDOM">Random Traffic</option>
            <option value="NORMAL">Normal Only</option>
            <option value="DoS">DoS Attack Simulation</option>
            <option value="Probe">Probe Attack Simulation</option>
            <option value="R2L">R2L Attack Simulation</option>
            <option value="U2R">U2R Attack Simulation</option>
          </select>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-[10px] font-bold text-text-dim uppercase">Throughput</span>
          <input 
            type="range" 
            min="1" 
            max="10" 
            value={packetsPerSecond}
            onChange={(e) => setPacketsPerSecond(parseInt(e.target.value))}
            className="w-32 accent-neon-blue"
          />
          <span className="text-xs font-mono font-bold text-neon-blue">{packetsPerSecond} p/s</span>
        </div>

        <div className="flex-1" />

        <div className="flex items-center gap-2">
          {!isRunning ? (
            <button 
              onClick={() => setIsRunning(true)}
              className="flex items-center gap-2 bg-neon-green text-bg-primary px-4 py-1.5 rounded-md font-bold text-xs hover:bg-white transition-all glow-green"
            >
              <Play className="w-3 h-3 fill-current" />
              Start Monitoring
            </button>
          ) : (
            <button 
              onClick={() => setIsRunning(false)}
              className="flex items-center gap-2 bg-neon-red text-white px-4 py-1.5 rounded-md font-bold text-xs hover:bg-white hover:text-bg-primary transition-all glow-red"
            >
              <Square className="w-3 h-3 fill-current" />
              Stop System
            </button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        {/* Tabs */}
        <div className="flex border-b border-border-dim mb-6 overflow-x-auto no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`flex items-center gap-2 px-6 py-3 text-xs font-bold uppercase tracking-widest transition-all border-b-2 whitespace-nowrap ${
                activeTab === tab.id 
                  ? 'border-neon-blue text-neon-blue bg-neon-blue/5' 
                  : 'border-transparent text-text-dim hover:text-white hover:bg-white/5'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="animate-in fade-in duration-500">
          {activeTab === 'monitor' && (
            <LiveMonitor 
              history={history} 
              anomalyScores={anomalyScores} 
              totalPackets={totalPackets} 
              attackCounts={attackCounts}
              isRunning={isRunning}
            />
          )}
          {activeTab === 'analytics' && <Analytics history={history} />}
          {activeTab === 'model' && <ModelPerformance />}
          {activeTab === 'explain' && <ExplainAlert />}
          {activeTab === 'logs' && <LogsPanel history={history} />}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-bg-card border-t border-border-dim px-6 py-3 flex items-center justify-between text-[10px] text-text-muted font-bold uppercase tracking-widest">
        <div>© 2026 Aegis Cyber-Defense Systems. All Rights Reserved.</div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-neon-green" />
            Database: Connected
          </span>
          <span className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-neon-green" />
            ML Engine: Online
          </span>
          <span className="text-neon-blue">Encrypted Session: AES-256</span>
        </div>
      </footer>
    </div>
  );
}

