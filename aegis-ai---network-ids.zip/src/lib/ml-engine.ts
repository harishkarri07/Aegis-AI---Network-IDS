/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AttackCategory, AttackExplanation, FeatureImportance, Indicator } from '../types';

// Feature names based on KDD Cup '99
export const FEATURE_NAMES = [
  'duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes',
  'land', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in',
  'num_compromised', 'root_shell', 'su_attempted', 'num_root', 'num_file_creations',
  'num_shells', 'num_access_files', 'num_outbound_cmds'
];

export class MLEngine {
  static predict(features: number[]): { 
    category: AttackCategory; 
    confidence: number; 
    is_anomaly: boolean; 
    iso_score: number;
    binary: 0 | 1;
  } {
    // Simulate model logic
    // In a real app, this would be a call to a serialized model (ONNX or similar)
    // or a Python backend. Here we simulate the decision boundaries.
    
    let category: AttackCategory = 'NORMAL';
    let confidence = 0.95 + Math.random() * 0.05;
    let iso_score = Math.random() * 0.5; // Lower is more anomalous
    
    const src_bytes = features[4];
    const duration = features[0];
    const logged_in = features[11];
    const hot = features[9];
    
    // DoS Simulation: High src_bytes, high duration
    if (src_bytes > 50000 && duration > 2) {
      category = 'DoS';
      confidence = 0.88 + Math.random() * 0.1;
      iso_score = -0.2 - Math.random() * 0.3;
    } 
    // Probe Simulation: Low src_bytes, high duration, not logged in
    else if (duration > 10 && logged_in === 0) {
      category = 'Probe';
      confidence = 0.82 + Math.random() * 0.15;
      iso_score = -0.1 - Math.random() * 0.2;
    }
    // R2L Simulation: High 'hot' indicators, failed logins
    else if (hot > 5) {
      category = 'R2L';
      confidence = 0.75 + Math.random() * 0.2;
      iso_score = -0.3 - Math.random() * 0.2;
    }
    // U2R Simulation: Root shell access, num_compromised
    else if (features[13] === 1 || features[12] > 0) {
      category = 'U2R';
      confidence = 0.7 + Math.random() * 0.25;
      iso_score = -0.4 - Math.random() * 0.4;
    }

    const is_anomaly = iso_score < 0;
    const binary: 0 | 1 = category === 'NORMAL' ? 0 : 1;

    return { category, confidence, is_anomaly, iso_score, binary };
  }

  static explain(category: AttackCategory, features: number[]): AttackExplanation {
    const profiles: Record<AttackCategory, Partial<AttackExplanation>> = {
      'NORMAL': {
        attack_name: 'Normal Traffic',
        severity: 'NORMAL',
        narrative: 'The traffic pattern matches baseline legitimate network activity.',
        mitigation: 'No action required. Continue monitoring.',
        icon: '🛡️'
      },
      'DoS': {
        attack_name: 'Denial of Service (DoS)',
        severity: 'CRITICAL',
        narrative: 'High volume of data detected from a single source, likely attempting to exhaust server resources.',
        mitigation: 'Implement rate limiting on the source IP and check firewall rules for flood protection.',
        icon: '🚫'
      },
      'Probe': {
        attack_name: 'Network Probing / Scanning',
        severity: 'HIGH',
        narrative: 'Sequential port scanning or unusual service discovery patterns detected.',
        mitigation: 'Block the source IP and ensure all unused ports are closed and stealthy.',
        icon: '🔍'
      },
      'R2L': {
        attack_name: 'Remote-to-Local (R2L)',
        severity: 'HIGH',
        narrative: 'Unauthorized access attempt from a remote machine to a local account.',
        mitigation: 'Enforce multi-factor authentication and review access logs for the targeted account.',
        icon: '🔓'
      },
      'U2R': {
        attack_name: 'User-to-Root (U2R)',
        severity: 'CRITICAL',
        narrative: 'Privilege escalation attempt detected. A local user is trying to gain root/admin access.',
        mitigation: 'Immediate audit of system binaries and user permissions. Isolate the affected host.',
        icon: '👑'
      }
    };

    const profile = profiles[category]!;
    
    // Generate simulated indicators
    const indicators: Indicator[] = [];
    if (category === 'DoS') {
      indicators.push({ feature: 'src_bytes', value: features[4], threshold: '> 50000', description: 'Excessive data transfer' });
    } else if (category === 'Probe') {
      indicators.push({ feature: 'duration', value: features[0], threshold: '> 10s', description: 'Long-lived connection' });
    }

    // Generate simulated feature importance
    const top_features: FeatureImportance[] = FEATURE_NAMES.map(name => ({
      feature: name,
      importance: Math.random() * 0.3
    })).sort((a, b) => b.importance - a.importance).slice(0, 5);

    return {
      ...profile as AttackExplanation,
      indicators,
      top_features
    };
  }
}
