/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AttackCategory, Packet } from '../types';
import { MLEngine, FEATURE_NAMES } from './ml-engine';

const INTERNAL_IPS = ['192.168.1.10', '192.168.1.15', '10.0.0.5', '10.0.0.8'];
const EXTERNAL_IPS = ['172.217.16.14', '142.250.190.46', '31.13.71.36', '157.240.22.35'];
const PROTOCOLS = ['TCP', 'UDP', 'ICMP'];
const PORTS = [80, 443, 22, 21, 53, 3306, 8080];

export class TrafficSimulator {
  static generatePacket(forceType?: AttackCategory): Packet {
    const isAttack = forceType ? forceType !== 'NORMAL' : Math.random() < 0.15;
    const category: AttackCategory = forceType || (isAttack ? this.getRandomAttack() : 'NORMAL');
    
    const src_ip = isAttack ? this.getRandomIP(EXTERNAL_IPS) : this.getRandomIP(INTERNAL_IPS);
    const dst_ip = this.getRandomIP(INTERNAL_IPS);
    const dst_port = PORTS[Math.floor(Math.random() * PORTS.length)];
    const protocol = PROTOCOLS[Math.floor(Math.random() * PROTOCOLS.length)];
    
    // Generate features based on category
    const features = FEATURE_NAMES.map(() => Math.random());
    
    if (category === 'DoS') {
      features[4] = 60000 + Math.random() * 40000; // src_bytes
      features[0] = 5 + Math.random() * 10; // duration
    } else if (category === 'Probe') {
      features[0] = 15 + Math.random() * 20; // duration
      features[11] = 0; // logged_in
    } else if (category === 'R2L') {
      features[9] = 8 + Math.random() * 5; // hot
    } else if (category === 'U2R') {
      features[13] = 1; // root_shell
      features[12] = 2; // num_compromised
    }

    const prediction = MLEngine.predict(features);
    const explanation = MLEngine.explain(prediction.category, features);

    return {
      id: Math.random().toString(36).substring(2, 11),
      timestamp: new Date().toISOString(),
      src_ip,
      dst_ip,
      dst_port,
      protocol,
      ...prediction,
      explanation,
      features
    };
  }

  private static getRandomAttack(): AttackCategory {
    const attacks: AttackCategory[] = ['DoS', 'Probe', 'R2L', 'U2R'];
    return attacks[Math.floor(Math.random() * attacks.length)];
  }

  private static getRandomIP(pool: string[]): string {
    return pool[Math.floor(Math.random() * pool.length)];
  }
}
