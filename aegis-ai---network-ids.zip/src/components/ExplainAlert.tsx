/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, ShieldAlert, Info, CheckCircle, AlertCircle } from 'lucide-react';
import { AttackCategory, Packet } from '../types';
import { AlertBox } from './AlertBox';
import { ConfidenceGauge } from './ConfidenceGauge';

export const ExplainAlert: React.FC = () => {
  const [selectedType, setSelectedType] = useState<AttackCategory>('DoS');
  const [explanation, setExplanation] = useState<Packet | null>(null);
  const [loading, setLoading] = useState(false);

  const generateExplanation = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ count: 1, force_type: selectedType })
      });
      const data = await res.json();
      setExplanation(data.packets[0]);
    } catch (error) {
      console.error('Error generating explanation:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="ids-card">
        <h3 className="text-sm font-bold uppercase tracking-widest mb-6 flex items-center gap-2">
          <Search className="w-4 h-4 text-neon-blue" />
          AI Attack Explainer
        </h3>
        
        <div className="flex flex-col md:flex-row gap-4 items-end">
          <div className="flex-1 space-y-2">
            <label className="text-[10px] text-text-dim uppercase font-bold">Select Attack Vector to Analyze</label>
            <select 
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as AttackCategory)}
              className="w-full bg-bg-primary border border-border-dim rounded-lg px-4 py-2.5 text-sm font-bold focus:outline-none focus:border-neon-blue transition-colors"
            >
              <option value="DoS">Denial of Service (DoS)</option>
              <option value="Probe">Network Probing / Scanning</option>
              <option value="R2L">Remote-to-Local (R2L)</option>
              <option value="U2R">User-to-Root (U2R)</option>
              <option value="NORMAL">Normal Baseline</option>
            </select>
          </div>
          <button 
            onClick={generateExplanation}
            disabled={loading}
            className="bg-neon-blue text-bg-primary px-6 py-2.5 rounded-lg font-bold hover:bg-white transition-all disabled:opacity-50 flex items-center gap-2"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-bg-primary border-t-transparent rounded-full animate-spin" />
            ) : (
              <ShieldAlert className="w-4 h-4" />
            )}
            Generate AI Explanation
          </button>
        </div>
      </div>

      {explanation && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <div className="ids-card">
              <h4 className="text-[10px] text-text-dim uppercase font-bold mb-4">Detection Summary</h4>
              <AlertBox packet={explanation} />
              <div className="mt-4 bg-black/20 rounded-lg p-2 border border-white/5">
                <ConfidenceGauge confidence={explanation.confidence} />
              </div>
            </div>

            <div className="ids-card bg-neon-green/5 border-neon-green/20">
              <h4 className="text-[10px] text-neon-green uppercase font-bold mb-3 flex items-center gap-2">
                <CheckCircle className="w-3 h-3" />
                Recommended Mitigation
              </h4>
              <p className="text-xs leading-relaxed text-neon-green/80 italic">
                {explanation.explanation?.mitigation}
              </p>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div className="ids-card">
              <h4 className="text-[10px] text-text-dim uppercase font-bold mb-4 flex items-center gap-2">
                <Info className="w-4 h-4 text-neon-blue" />
                Triggered Indicators & Thresholds
              </h4>
              <div className="space-y-3">
                {explanation.explanation?.indicators.map((ind, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 bg-white/5 rounded-lg border border-white/5">
                    <div className="mt-1">
                      <AlertCircle className="w-4 h-4 text-neon-orange" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-mono font-bold text-white">{ind.feature}</span>
                        <span className="text-[10px] bg-neon-orange/20 text-neon-orange px-1.5 py-0.5 rounded border border-neon-orange/30">
                          Value: {typeof ind.value === 'number' ? ind.value.toFixed(2) : ind.value}
                        </span>
                        <span className="text-[10px] text-text-dim">Threshold: {ind.threshold}</span>
                      </div>
                      <p className="text-[11px] text-text-dim">{ind.description}</p>
                    </div>
                  </div>
                ))}
                {explanation.explanation?.indicators.length === 0 && (
                  <p className="text-xs text-text-muted italic">No specific threshold indicators triggered for this pattern.</p>
                )}
              </div>
            </div>

            <div className="ids-card">
              <h4 className="text-[10px] text-text-dim uppercase font-bold mb-4 flex items-center gap-2">
                <Search className="w-4 h-4 text-neon-blue" />
                Top Contributing Features
              </h4>
              <div className="space-y-4">
                {explanation.explanation?.top_features.map((feat, i) => (
                  <div key={i} className="space-y-1">
                    <div className="flex justify-between text-[10px]">
                      <span className="font-mono text-text-dim">{feat.feature}</span>
                      <span className="text-neon-blue font-bold">{(feat.importance * 100).toFixed(1)}% weight</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-neon-blue shadow-[0_0_10px_rgba(0,212,255,0.5)]" 
                        style={{ width: `${Math.min(feat.importance * 500, 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
