/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Brain, Cpu, Database, Network, ShieldCheck } from 'lucide-react';
import { FeatureImportance, IDSMetadata } from '../types';
import { FeatureImportanceChart } from './FeatureImportanceChart';

export const ModelPerformance: React.FC = () => {
  const [metadata, setMetadata] = useState<IDSMetadata | null>(null);
  const [importances, setImportances] = useState<FeatureImportance[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [metaRes, featRes] = await Promise.all([
          fetch('/api/metadata'),
          // Simulate feature importance since we don't have a real model file
          Promise.resolve({
            json: () => Promise.resolve([
              { feature: 'src_bytes', importance: 0.28 },
              { feature: 'dst_bytes', importance: 0.22 },
              { feature: 'duration', importance: 0.15 },
              { feature: 'logged_in', importance: 0.12 },
              { feature: 'hot', importance: 0.08 },
              { feature: 'num_failed_logins', importance: 0.05 },
              { feature: 'root_shell', importance: 0.04 },
              { feature: 'num_compromised', importance: 0.03 },
              { feature: 'protocol_type', importance: 0.02 },
              { feature: 'service', importance: 0.01 }
            ])
          })
        ]);
        
        const meta = await metaRes.json();
        const feats = await featRes.json();
        
        setMetadata(meta);
        setImportances(feats);
      } catch (error) {
        console.error('Error fetching model data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-neon-blue"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Model Info */}
        <div className="ids-card lg:col-span-1 space-y-6">
          <h3 className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
            <Brain className="w-4 h-4 text-neon-blue" />
            Model Architecture
          </h3>
          
          <div className="space-y-4">
            <div className="p-3 bg-white/5 rounded-lg border border-white/5">
              <div className="flex items-center gap-2 mb-1">
                <Cpu className="w-4 h-4 text-neon-green" />
                <span className="text-xs font-bold text-neon-green uppercase">Primary Classifier</span>
              </div>
              <p className="text-sm font-bold">Random Forest Ensemble</p>
              <p className="text-[10px] text-text-dim">100 estimators, Gini impurity, max_depth=20</p>
            </div>

            <div className="p-3 bg-white/5 rounded-lg border border-white/5">
              <div className="flex items-center gap-2 mb-1">
                <ShieldCheck className="w-4 h-4 text-neon-pink" />
                <span className="text-xs font-bold text-neon-pink uppercase">Anomaly Detector</span>
              </div>
              <p className="text-sm font-bold">Isolation Forest</p>
              <p className="text-[10px] text-text-dim">Contamination=0.1, n_estimators=100</p>
            </div>

            <div className="p-3 bg-white/5 rounded-lg border border-white/5">
              <div className="flex items-center gap-2 mb-1">
                <Database className="w-4 h-4 text-neon-blue" />
                <span className="text-xs font-bold text-neon-blue uppercase">Training Dataset</span>
              </div>
              <p className="text-sm font-bold">NSL-KDD Augmented</p>
              <p className="text-[10px] text-text-dim">{metadata?.n_train.toLocaleString()} samples, {metadata?.feature_names.length} features</p>
            </div>
          </div>
        </div>

        {/* Feature Importance */}
        <div className="ids-card lg:col-span-2">
          <h3 className="text-sm font-bold uppercase tracking-widest mb-6 flex items-center gap-2">
            <Network className="w-4 h-4 text-neon-blue" />
            Feature Importance (SHAP Values)
          </h3>
          <FeatureImportanceChart importances={importances} />
        </div>
      </div>

      {/* Comparison Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="ids-card border-l-4 border-l-neon-blue">
          <h4 className="font-bold mb-2">Signature-Based Detection</h4>
          <p className="text-xs text-text-dim leading-relaxed">
            Uses the Random Forest model to classify traffic into known attack categories (DoS, Probe, etc.) based on historical patterns. High precision for known threats.
          </p>
        </div>
        <div className="ids-card border-l-4 border-l-neon-pink">
          <h4 className="font-bold mb-2">Behavioral Anomaly Detection</h4>
          <p className="text-xs text-text-dim leading-relaxed">
            Uses Isolation Forest to identify "outliers" that don't match normal baseline behavior. Essential for detecting zero-day attacks and novel intrusion attempts.
          </p>
        </div>
      </div>
    </div>
  );
};
